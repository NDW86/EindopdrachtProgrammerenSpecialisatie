﻿using System;

namespace ExamenOpdracht_DeWildeNico
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
